import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  Home,
  Zap,
  QrCode,
  Bell,
  Armchair,
  Calendar,
  MapPin,
  Headset,
  User,
  LogOut,
  Bus,
  Clock,
  Flag,
  Users,
  IdCard,
  CircleUser,
  X,
  ChevronRight,
  Phone,
  Mail,
  CircleCheck,
  TriangleAlert,
  Map,
  CalendarDays,
  Navigation,
  RefreshCw,
  Gauge,
  Power,
} from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './App.css';

/* ============================================
   FIX LEAFLET DEFAULT MARKER ICONS
   ============================================ */
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

/* ============================================
   IMAGES
   ============================================ */
const IMAGES = {
  logo: '/Logo.png',
  busDetails: '/Bus_details.png',
  busView: '/Bus_view.png',
};

/* ============================================
   API CONFIG
   ============================================ */
const API_BASE = 'http://localhost:5000/api/admin/gps';
const WHEELSEYE_API_URL =
  'https://api.wheelseye.com/currentLoc?accessToken=98a3355b-4498-48bb-8b70-7b0b04475788';

/* ============================================
   MOBILE DETECTION HOOK
   ============================================ */
function useIsMobile(breakpoint = 900) {
  const [isMobile, setIsMobile] = useState(
    typeof window !== 'undefined' ? window.innerWidth <= breakpoint : false
  );
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth <= breakpoint);
    window.addEventListener('resize', onResize);
    onResize();
    return () => window.removeEventListener('resize', onResize);
  }, [breakpoint]);
  return isMobile;
}

/* ============================================
   LIVE VEHICLES HOOK  (WheelsEye → backend fallback)
   ============================================ */
function useLiveVehicles(active = true, intervalMs = 15000) {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [, setTick] = useState(0);

  const abortRef = useRef(null);
  const timerRef = useRef(null);

  const fetchOnce = useCallback(async () => {
    if (abortRef.current) abortRef.current.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    try {
      let list = null;
      let fetchError = null;

      // 1) Try backend local API first (if running)
      try {
        const res = await fetch(`${API_BASE}/latest`, { signal: controller.signal });
        if (res.ok) {
          const json = await res.json();
          list = json?.data?.list ?? json?.data ?? json?.list ?? [];
        }
      } catch (err) {
        // ignore, fallback
      }

      // 2) Try backend /buses
      if (!list || list.length === 0) {
        try {
          const res = await fetch(`${API_BASE}/buses`, { signal: controller.signal });
          if (res.ok) {
            const json = await res.json();
            list = json?.data?.list ?? json?.data ?? [];
          }
        } catch (err) { /* ignore */ }
      }

      // 3) Try WheelsEye
      if (!list || list.length === 0) {
        try {
          const res = await fetch(WHEELSEYE_API_URL, { signal: controller.signal });
          if (res.ok) {
            const json = await res.json();
            list = json?.data?.data?.list ?? json?.data?.list ?? [];
          }
        } catch (err) { /* ignore */ }
      }

      if (!list) throw fetchError || new Error('No data source available');

      // Merge by deviceNumber so React reuses DOM nodes
      setVehicles((prev) => {
        const byId = new Map(prev.map((v) => [v.deviceNumber, v]));
        list.forEach((v) => byId.set(v.deviceNumber, v));
        return list.map((v) => byId.get(v.deviceNumber) ?? v);
      });

      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      if (err.name !== 'AbortError') {
        setError(err.message || 'Failed to load vehicle locations');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  // Poll loop
  useEffect(() => {
    if (!active) return;

    fetchOnce();

    const start = () => {
      if (timerRef.current) return;
      timerRef.current = setInterval(fetchOnce, intervalMs);
    };
    const stop = () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
    const onVisibility = () => {
      if (document.hidden) stop();
      else {
        fetchOnce();
        start();
      }
    };

    start();
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      stop();
      document.removeEventListener('visibilitychange', onVisibility);
      if (abortRef.current) abortRef.current.abort();
    };
  }, [active, intervalMs, fetchOnce]);

  // 1s tick so "Updated Xs ago" re-renders
  useEffect(() => {
    if (!active) return;
    const id = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, [active]);

  return { vehicles, loading, error, lastUpdated, refresh: fetchOnce };
}

/* ============================================
   VEHICLE ICON (L.divIcon)
   ============================================ */
function createVehicleIcon(vehicle, isSelected) {
  const isMoving = (vehicle.speed || 0) > 0;
  const isOpen = vehicle.vehicleType === 'Open';

  let bgColor = '#7a8ba3';
  if (isMoving) bgColor = '#10a56a';
  else if (isOpen) bgColor = '#e68a2e';
  if (isSelected) bgColor = '#1e6fdf';

  const iconHtml = `
    <div style="width:36px;height:36px;border-radius:50% 50% 50% 0;background:${bgColor};transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.25);border:2px solid white;${isMoving ? 'animation:pulse 1.5s infinite' : ''}">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transform:rotate(45deg)">
        <path d="M18 19V7a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v12" />
        <path d="M2 19h20" />
        <path d="M6 19V5" />
        <path d="M18 19V5" />
      </svg>
    </div>
    <style>@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(16,165,106,0.5)}70%{box-shadow:0 0 0 12px rgba(16,165,106,0)}100%{box-shadow:0 0 0 0 rgba(16,165,106,0)}}</style>
  `;
  return L.divIcon({
    html: iconHtml,
    className: 'custom-vehicle-marker',
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -36],
  });
}

/* ============================================
   MAP CONTROLLER  (must live INSIDE <MapContainer>)
   Recenters the map when a vehicle is selected.
   ============================================ */
function MapController({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.setView(center, zoom || map.getZoom());
    }
  }, [center, zoom, map]);
  return null;
}

/* ============================================
   GPS DASHBOARD  (map + vehicle list)
   ============================================ */
function GpsDashboard({ vehicles, loading, error, lastUpdated, onRefresh, isMobile }) {
  const [selectedVehicle, setSelectedVehicle] = useState(null);

  const validVehicles = (vehicles || []).filter(
    (v) =>
      v &&
      typeof v.latitude === 'number' &&
      typeof v.longitude === 'number' &&
      !isNaN(v.latitude) &&
      !isNaN(v.longitude)
  );

  const center = selectedVehicle
    ? [selectedVehicle.latitude, selectedVehicle.longitude]
    : validVehicles.length
    ? [validVehicles[0].latitude, validVehicles[0].longitude]
    : [19.9369, 79.1193];

  return (
    <div className="dashboard-container gps-dashboard">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">GPS Dashboard</h1>
          <p className="dashboard-subtitle">
            Live vehicle locations · {validVehicles.length} on map
          </p>
        </div>
        <div className="dashboard-actions">
          <button
            className="btn btn-ghost btn-sm"
            onClick={onRefresh}
            disabled={loading}
            title="Refresh"
          >
            <RefreshCw size={16} className={loading ? 'spinning' : ''} />
            {!isMobile && 'Refresh'}
          </button>
        </div>
      </div>

      {error && (
        <div className="alert alert-error" style={{ marginBottom: '1rem' }}>
          <TriangleAlert size={16} /> {error}
        </div>
      )}

      {lastUpdated && (
        <div className="text-muted" style={{ marginBottom: '0.75rem', fontSize: '0.875rem' }}>
          Last updated: {new Date(lastUpdated).toLocaleTimeString()}
        </div>
      )}

      <div className={`gps-dashboard-layout ${isMobile ? 'mobile' : ''}`}>
        <div className="gps-map-wrapper">
          <MapContainer
            center={center}
            zoom={13}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapController
              center={
                selectedVehicle
                  ? [selectedVehicle.latitude, selectedVehicle.longitude]
                  : null
              }
              zoom={15}
            />
            {validVehicles.map((v, idx) => (
              <Marker
                key={v.deviceNumber || v.vehicleNumber || idx}
                position={[v.latitude, v.longitude]}
                icon={createVehicleIcon(
                  v,
                  selectedVehicle?.deviceNumber === v.deviceNumber
                )}
                eventHandlers={{ click: () => setSelectedVehicle(v) }}
              >
                <Popup>
                  <div style={{ minWidth: 200 }}>
                    <strong>{v.vehicleNumber || 'N/A'}</strong>
                    <div>Device: {v.deviceNumber || 'N/A'}</div>
                    <div>Speed: {v.speed ?? 0} km/h</div>
                    <div>Ignition: {v.ignition ? 'On' : 'Off'}</div>
                    <div>Type: {v.vehicleType || 'NA'}</div>
                    <div>Vendor: {v.venndorName || v.vendorName || '—'}</div>
                    <div>
                      Updated: {v.dttime || v.createdDateReadable || '—'}
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>

        <div className="gps-list-wrapper">
          <div className="gps-list-header">
            <h3>Vehicles ({vehicles.length})</h3>
          </div>
          <div className="gps-list">
            {vehicles.length === 0 && !loading && (
              <div className="text-muted" style={{ padding: '1rem', textAlign: 'center' }}>
                No vehicles found
              </div>
            )}
            {vehicles.map((v, idx) => (
              <div
                key={v.deviceNumber || v.vehicleNumber || idx}
                className={`gps-list-item ${
                  selectedVehicle?.deviceNumber === v.deviceNumber ? 'active' : ''
                }`}
                onClick={() => setSelectedVehicle(v)}
              >
                <div className="gps-list-item-title">
                  {v.vehicleNumber || 'Unknown'}
                </div>
                <div className="gps-list-item-sub">
                  {v.venndorName || v.vendorCode || ''}
                </div>
                <div className="gps-list-item-meta">
                  <span>{v.speed ?? 0} km/h</span>
                  <span>{v.dttime || v.createdDateReadable || '—'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================
   MAIN APP
   ============================================ */
function App() {
  const isMobile = useIsMobile(900);

  const [activeTab, setActiveTab] = useState('Home');
  const [showQADropdown, setShowQADropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [toast, setToast] = useState({ show: false, message: '' });
  const [modal, setModal] = useState(null);
  const [mapEndpoints, setMapEndpoints] = useState({
    start: 'Lloyds Colony',
    end: 'Steel Plant Main Gate',
  });
  const [scheduleFilter, setScheduleFilter] = useState('all');

  const qaTabRef = useRef(null);
  const profileBtnRef = useRef(null);

  // 👇 Live GPS — only poll while GPS modal is open
  const {
    vehicles: gpsVehicles,
    loading: gpsLoading,
    error: gpsError,
    lastUpdated: gpsLastUpdated,
    refresh: refreshGps,
  } = useLiveVehicles(modal === 'gps', 15000);

  const showToast = (message) => {
    setToast({ show: true, message });
    setTimeout(() => setToast({ show: false, message: '' }), 2500);
  };

  // Close dropdowns on outside click
  useEffect(() => {
    const onClick = (event) => {
      if (qaTabRef.current && !qaTabRef.current.contains(event.target)) {
        setShowQADropdown(false);
      }
      if (profileBtnRef.current && !profileBtnRef.current.contains(event.target)) {
        setShowProfileDropdown(false);
      }
    };
    document.addEventListener('click', onClick);
    return () => document.removeEventListener('click', onClick);
  }, []);

  /* ---------- HANDLERS ---------- */
  const handleTabClick = (tab) => {
    setActiveTab(tab);
    if (tab === 'My Pass') setModal('qr');
    else if (tab === 'Profile') setModal('profile');
    else setModal(null);
  };

  const handleToggleProfile = (e) => {
    e.stopPropagation();
    setShowQADropdown(false);
    setShowProfileDropdown((v) => !v);
  };

  const handleLogout = () => {
    setShowProfileDropdown(false);
    if (window.confirm('Are you sure you want to logout?')) {
      showToast('Logged out successfully');
    }
  };

  const handleSelectSchedule = (id) => {
    setSelectedSchedule(id);
    const item = scheduleData.find((s) => s.id === id);
    if (item) showToast(`Selected: ${item.time} from ${item.fromLocation}`);
  };

  const openMapModal = (start, end) => {
    setMapEndpoints({ start, end });
    setModal('map');
  };

  const openGpsDashboard = () => setModal('gps');
  const closeModal = () => setModal(null);

  const handleQuickAction = (action) => {
    setShowQADropdown(false);
    switch (action) {
      case 'bookSeat': setModal('booking'); break;
      case 'myBookings': setModal('myBookings'); break;
      case 'trackBus': openGpsDashboard(); break;
      case 'support': setModal('support'); break;
      default: break;
    }
  };

  /* ---------- SCHEDULE DATA ---------- */
  const scheduleData = [
    { id: 1, time: '07:30 AM', period: 'Pickup', fromLocation: 'Lloyds Colony', fromSub: 'Near Main Gate', toLocation: 'Steel Plant Main Gate', toSub: 'End Destination', status: 'On Time' },
    { id: 2, time: '08:00 AM', period: 'Pickup', fromLocation: 'Lloyds Colony', fromSub: 'Near Main Gate', toLocation: 'Steel Plant Main Gate', toSub: 'End Destination', status: 'On Time' },
    { id: 3, time: '08:30 AM', period: 'Pickup', fromLocation: 'Lloyds Colony', fromSub: 'Near Main Gate', toLocation: 'Steel Plant Main Gate', toSub: 'End Destination', status: 'Delayed' },
    { id: 4, time: '09:15 AM', period: 'Pickup', fromLocation: 'Lloyds Colony', fromSub: 'Near Main Gate', toLocation: 'Steel Plant Main Gate', toSub: 'End Destination', status: 'On Time' },
    { id: 5, time: '12:30 PM', period: 'Pickup', fromLocation: 'Steel Plant', fromSub: 'Admin Building', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'On Time' },
    { id: 6, time: '01:00 PM', period: 'Pickup', fromLocation: 'Steel Plant', fromSub: 'Admin Building', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'On Time' },
    { id: 7, time: '05:30 PM', period: 'Drop', fromLocation: 'Steel Plant', fromSub: 'Main Gate', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'On Time' },
    { id: 8, time: '06:15 PM', period: 'Drop', fromLocation: 'Steel Plant', fromSub: 'Main Gate', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'On Time' },
    { id: 9, time: '07:00 PM', period: 'Drop', fromLocation: 'Steel Plant', fromSub: 'Main Gate', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'Delayed' },
    { id: 10, time: '09:00 PM', period: 'Drop', fromLocation: 'Steel Plant', fromSub: 'Main Gate', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'On Time' },
    { id: 11, time: '10:30 PM', period: 'Drop', fromLocation: 'Steel Plant', fromSub: 'Main Gate', toLocation: 'Lloyds Colony', toSub: 'End Destination', status: 'On Time' },
  ];

  const filteredSchedule = scheduleData.filter((item) => {
    if (scheduleFilter === 'all') return true;
    if (scheduleFilter === 'pickup') return item.period === 'Pickup';
    if (scheduleFilter === 'drop') return item.period === 'Drop';
    if (scheduleFilter === 'delayed') return item.status === 'Delayed';
    return true;
  });

  /* ---------- STYLES ---------- */
  const actionBtnStyle = {
    display: 'flex',
    flexDirection: isMobile ? 'row' : 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    padding: isMobile ? '10px 8px' : '12px 6px',
    border: '1px solid var(--border-color)',
    borderRadius: '10px',
    background: '#fff',
    fontSize: isMobile ? '11px' : '10px',
    fontWeight: 600,
    gap: '6px',
    margin: 0,
    boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    cursor: 'pointer',
    color: 'var(--text-dark)',
    fontFamily: 'inherit',
    transition: 'all 0.2s ease',
    width: '100%',
    flex: isMobile ? '1' : 'unset',
    minWidth: isMobile ? '0' : 'auto',
  };

  const actionIconStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '28px',
    height: '28px',
    borderRadius: '8px',
    background: '#FFF0F0',
    color: '#D32F2F',
    flexShrink: 0,
  };

  const mobileTabStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '2px',
    padding: '6px 4px',
    background: 'transparent',
    border: 'none',
    cursor: 'pointer',
    color: '#757575',
    fontFamily: 'inherit',
    fontSize: '9px',
    fontWeight: 500,
    flex: '0 0 auto',
    minWidth: '56px',
    transition: 'color 0.2s ease',
  };

  const mobileTabIconStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '22px',
    height: '22px',
  };

  /* ---------- RENDER ---------- */
  return (
    <div className="app-container" style={{ paddingBottom: isMobile ? '90px' : '0' }}>
      {/* ============ TOP BAR ============ */}
      <div className="top-bar" style={{ padding: isMobile ? '10px 14px' : '12px 24px' }}>
        <div className="top-bar-left">
          <div className="logo-image">
            <img
              src={IMAGES.logo}
              alt="Lloyds Metals Logo"
              style={{ height: isMobile ? '28px' : '36px' }}
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.nextElementSibling.style.display = 'block';
              }}
            />
            <div className="logo-placeholder" style={{ display: 'none' }}>
              LLOYDS METALS <br />
              <span style={{ fontSize: '6px', color: '#aaa' }}>AND ENERGY LIMITED</span>
            </div>
          </div>
        </div>

        <div className="top-bar-right" style={{ gap: isMobile ? '8px' : '16px' }}>
          <div className="top-nav-tabs" style={{ display: isMobile ? 'none' : 'flex' }}>
            <div
              className={`top-nav-item ${activeTab === 'My Pass' ? 'active' : ''}`}
              onClick={() => handleTabClick('My Pass')}
            >
              <QrCode size={16} />
              <span>My Pass</span>
            </div>
          </div>

          <div
            className="notification-icon"
            onClick={() => setModal('notifications')}
            style={{ width: isMobile ? '34px' : '38px', height: isMobile ? '34px' : '38px' }}
          >
            <Bell size={isMobile ? 18 : 20} />
          </div>

          <div
            ref={profileBtnRef}
            className="profile-avatar-btn"
            onClick={handleToggleProfile}
            title="Account"
            style={{
              width: isMobile ? '34px' : '38px',
              height: isMobile ? '34px' : '38px',
              fontSize: isMobile ? '11px' : '13px',
            }}
          >
            RV
          </div>
        </div>
      </div>

      {/* ============ QUICK ACTIONS DROPDOWN ============ */}
      {showQADropdown && (
        <div className="quick-actions-dropdown show">
          <div className="qa-dropdown-header">
            <h4><Zap size={14} /> Quick Actions</h4>
          </div>
          <div className="qa-dropdown-item" onClick={() => handleQuickAction('bookSeat')}>
            <div className="qa-icon"><Armchair size={15} /></div>
            <span>Book Seat</span>
          </div>
          <div className="qa-dropdown-item" onClick={() => handleQuickAction('myBookings')}>
            <div className="qa-icon"><Calendar size={15} /></div>
            <span>My Bookings</span>
          </div>
          <div className="qa-dropdown-item" onClick={() => handleQuickAction('trackBus')}>
            <div className="qa-icon"><Navigation size={15} /></div>
            <span>GPS Dashboard</span>
          </div>
          <div className="qa-dropdown-item" onClick={() => handleQuickAction('support')}>
            <div className="qa-icon"><Headset size={15} /></div>
            <span>Support</span>
          </div>
        </div>
      )}

      {/* ============ PROFILE DROPDOWN ============ */}
      {showProfileDropdown && (
        <div
          className="profile-dropdown show"
          style={{ right: isMobile ? '14px' : '24px', width: isMobile ? '220px' : '240px' }}
        >
          <div className="profile-dropdown-header">
            <div className="avatar-sm">RV</div>
            <div className="user-info">
              <h4>Rahul Verma</h4>
              <p>LM-45892</p>
            </div>
          </div>
          <div className="profile-dropdown-item" onClick={() => { setModal('profile'); setShowProfileDropdown(false); }}>
            <User size={16} /><span>My Profile</span>
          </div>
          <div className="profile-dropdown-item" onClick={() => { setModal('myBookings'); setShowProfileDropdown(false); }}>
            <Calendar size={16} /><span>My Bookings</span>
          </div>
          <div className="profile-dropdown-item" onClick={() => { openGpsDashboard(); setShowProfileDropdown(false); }}>
            <Navigation size={16} /><span>GPS Dashboard</span>
          </div>
          <div className="profile-dropdown-item" onClick={() => { setModal('support'); setShowProfileDropdown(false); }}>
            <Headset size={16} /><span>Support</span>
          </div>
          <div className="profile-dropdown-divider"></div>
          <div className="profile-dropdown-item logout" onClick={handleLogout}>
            <LogOut size={16} /><span>Logout</span>
          </div>
        </div>
      )}

      {/* ============ MAIN CONTENT ============ */}
      <div className="app-content" style={{ padding: isMobile ? '16px 14px' : '20px 24px' }}>
        <div className="hero" style={{ marginBottom: isMobile ? '18px' : '24px' }}>
          <h1 style={{ fontSize: isMobile ? '22px' : '26px' }}>Employee Transportation</h1>
          <p style={{ fontSize: isMobile ? '13px' : '14px' }}>Safe. Reliable. On time.</p>
        </div>

        <div style={{ display: 'flex', flexDirection: isMobile ? 'column' : 'row', gap: isMobile ? '14px' : '16px', alignItems: 'stretch' }}>
          <div
            className="main-grid"
            style={{
              flex: 1,
              minWidth: 0,
              display: 'grid',
              gridTemplateColumns: isMobile ? '1fr' : undefined,
              gap: isMobile ? '14px' : '20px',
            }}
          >
            {/* ----- LEFT COLUMN ----- */}
            <div className="col-left">
              <div className="section" style={{ padding: 0 }}>
                <h2 className="section-title-dark">My Next Ride</h2>
                <div className="card next-ride-card">
                  <div
                    className="ride-header"
                    style={{
                      flexDirection: isMobile ? 'column' : 'row',
                      alignItems: isMobile ? 'flex-start' : 'flex-start',
                      gap: isMobile ? '10px' : '0',
                    }}
                  >
                    <div className="bus-info">
                      <div className="bus-icon-box"><Bus size={16} /></div>
                      <div>
                        <h3>Tata Marco Polo Bus</h3>
                        <p>52 Seater</p>
                      </div>
                    </div>

                    <div className="ride-header-right" style={{ gap: isMobile ? '10px' : '26px', alignSelf: isMobile ? 'flex-start' : 'auto' }}>
                      <div className="badge-confirmed">Confirmed</div>
                      <button
                        className="gps-icon-btn"
                        onClick={openGpsDashboard}
                        title="Open GPS Dashboard"
                      >
                        <MapPin size={13} />
                        <span>GPS</span>
                      </button>
                    </div>
                  </div>

                  <div className="ride-route">
                    <div className="route-line">
                      <div className="dot"></div>
                      <div className="dash"></div>
                      <div className="dot" style={{ background: 'var(--dark-bg)' }}></div>
                    </div>
                    <div className="route-text">
                      <div className="destination-group">
                        <p>Lloyds Colony <span>Start Point</span></p>
                      </div>
                      <div className="destination-group">
                        <p>Steel Plant Main Gate <span>End Destination</span></p>
                      </div>
                    </div>
                  </div>

                  <div className="ride-footer" style={{ gap: isMobile ? '12px' : '16px' }}>
                    <div className="time-box">
                      <Clock size={14} />
                      <div><p>07:30 AM</p><p>Pickup Time</p></div>
                    </div>
                    <div className="time-box">
                      <Flag size={14} />
                      <div><p>07:50 AM</p><p>Drop Time</p></div>
                    </div>
                  </div>

                  <div className="bus-details-section">
                    <img
                      src={IMAGES.busView}
                      alt="Bus Details"
                      className="details-image"
                      style={{ height: isMobile ? '80px' : '100px' }}
                    />
                    <div className="details-footer" style={{ flexDirection: isMobile ? 'column' : 'row', gap: '8px' }}>
                      <div className="detail-item">
                        <Users size={13} />
                        <div>
                          <div>52 Seater</div>
                          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Tata Marco Polo</div>
                        </div>
                      </div>
                      <div className="detail-item">
                        <IdCard size={13} />
                        <div>
                          <div>MH 34 AB 1234</div>
                          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Registration No.</div>
                        </div>
                      </div>
                      <div className="detail-item">
                        <CircleUser size={13} />
                        <div>
                          <div>Rahul Verma</div>
                          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Driver</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ----- RIGHT COLUMN ----- */}
            <div className="col-right">
              <div className="section" style={{ padding: 0 }}>
                <h2 className="section-title-dark">Today's Schedule</h2>
                <div className="schedule-full-page">
                  <div
                    className="schedule-header"
                    style={{
                      flexDirection: isMobile ? 'column' : 'row',
                      alignItems: isMobile ? 'stretch' : 'center',
                      gap: isMobile ? '10px' : '0',
                    }}
                  >
                    <h2 className="section-title">Journey Details</h2>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginLeft: isMobile ? '0' : 'auto', justifyContent: 'space-between', width: isMobile ? '100%' : 'auto' }}>
                      <select
                        value={scheduleFilter}
                        onChange={(e) => setScheduleFilter(e.target.value)}
                        style={{
                          padding: '6px 10px',
                          border: '1px solid var(--border-color)',
                          borderRadius: '6px',
                          fontSize: isMobile ? '12px' : '11px',
                          background: '#fff',
                          color: 'var(--text-dark)',
                          cursor: 'pointer',
                          outline: 'none',
                          fontFamily: 'inherit',
                          flex: isMobile ? 1 : 'unset',
                        }}
                      >
                        <option value="all">All</option>
                        <option value="pickup">Pickup</option>
                        <option value="drop">Drop</option>
                        <option value="delayed">Delayed</option>
                      </select>

                      <div className="view-all" onClick={() => setModal('fullSchedule')}>
                        View Full <ChevronRight size={12} />
                      </div>
                    </div>
                  </div>

                  <div style={{ maxHeight: isMobile ? '300px' : '360px', overflowY: 'auto', paddingRight: '4px' }}>
                    {filteredSchedule.map((item) => (
                      <div
                        key={item.id}
                        className="schedule-item"
                        onClick={() => handleSelectSchedule(item.id)}
                        style={{
                          ...(selectedSchedule === item.id ? { backgroundColor: '#f9f9f9', borderRadius: '8px' } : {}),
                          flexWrap: isMobile ? 'wrap' : 'nowrap',
                          gap: isMobile ? '8px' : '12px',
                        }}
                      >
                        <div className="schedule-time">
                          {item.time} <span>{item.period}</span>
                        </div>
                        <div className="schedule-details">
                          <div className="schedule-dest-group">
                            <div className="schedule-dest-text">
                              <span className="dest-dot" style={{ background: 'var(--primary-red)' }} />
                              <div>{item.fromLocation} <span>{item.fromSub}</span></div>
                            </div>
                            <button
                              className="schedule-gps-btn"
                              onClick={(e) => { e.stopPropagation(); openGpsDashboard(); }}
                              title="Open GPS Dashboard"
                            >
                              <MapPin size={12} />
                              <span>GPS</span>
                            </button>
                          </div>
                          <div className="schedule-dest-group">
                            <div className="schedule-dest-text">
                              <span className="dest-dot" style={{ background: 'var(--dark-bg)' }} />
                              <div>{item.toLocation} <span>{item.toSub}</span></div>
                            </div>
                          </div>
                        </div>
                        <div
                          className="status-badge"
                          style={item.status === 'Delayed' ? { background: '#FFF3E0', color: '#E65100' } : {}}
                        >
                          {item.status}
                        </div>
                      </div>
                    ))}
                    {filteredSchedule.length === 0 && (
                      <p style={{ textAlign: 'center', color: 'var(--text-gray)', padding: '20px', fontSize: '12px' }}>
                        No schedules found.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ---------- DESKTOP QUICK ACTIONS ---------- */}
          {!isMobile && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '92px', flexShrink: 0, paddingTop: '32px' }}>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('bookSeat')}>
                <span style={actionIconStyle}><Armchair size={16} strokeWidth={2} /></span>
                <span>Book Seat</span>
              </button>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('myBookings')}>
                <span style={actionIconStyle}><Calendar size={16} strokeWidth={2} /></span>
                <span>My Bookings</span>
              </button>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('trackBus')}>
                <span style={actionIconStyle}><Navigation size={16} strokeWidth={2} /></span>
                <span>GPS</span>
              </button>
              <button type="button" style={actionBtnStyle} onClick={() => handleQuickAction('support')}>
                <span style={actionIconStyle}><Headset size={16} strokeWidth={2} /></span>
                <span>Support</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ============ MOBILE BOTTOM NAV ============ */}
      {isMobile && (
        <div className="bottom-nav" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '6px 8px', gap: '8px' }}>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('bookSeat')}>
            <span style={mobileTabIconStyle}><Armchair size={18} /></span>
            <span>Book</span>
          </button>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('myBookings')}>
            <span style={mobileTabIconStyle}><Calendar size={18} /></span>
            <span>Bookings</span>
          </button>
          <button
            type="button"
            style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              gap: '2px', background: 'transparent', border: 'none', cursor: 'pointer',
              color: '#D32F2F', fontFamily: 'inherit', fontSize: '9px', fontWeight: 600,
              flex: '0 0 auto', minWidth: '56px', position: 'relative', top: '-14px',
            }}
            onClick={() => setModal('qr')}
          >
            <span style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              width: '48px', height: '48px', borderRadius: '50%',
              background: '#D32F2F', color: '#fff',
              boxShadow: '0 6px 18px rgba(211,47,47,0.4)',
            }}>
              <QrCode size={22} />
            </span>
            <span style={{ color: '#D32F2F', marginTop: '2px' }}>My Pass</span>
          </button>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('trackBus')}>
            <span style={mobileTabIconStyle}><Navigation size={18} /></span>
            <span>GPS</span>
          </button>
          <button type="button" style={mobileTabStyle} onClick={() => handleQuickAction('support')}>
            <span style={mobileTabIconStyle}><Headset size={18} /></span>
            <span>Support</span>
          </button>
        </div>
      )}

      {/* ============ TOAST ============ */}
      <div
        className={`toast ${toast.show ? 'show' : ''}`}
        style={{
          bottom: isMobile ? '110px' : '100px',
          maxWidth: isMobile ? '90vw' : 'auto',
          whiteSpace: isMobile ? 'normal' : 'nowrap',
          textAlign: 'center',
        }}
      >
        {toast.message}
      </div>

      {/* ============ MODALS ============ */}

      {/* ---------- GPS DASHBOARD ---------- */}
      {modal === 'gps' && (
        <Modal onClose={closeModal} fullscreen>
          <div className="modal-header">
            <h3><Navigation size={18} /> GPS Dashboard — Live Vehicles</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <button
                className="close-modal"
                onClick={refreshGps}
                disabled={gpsLoading}
                title="Refresh now"
                style={{ opacity: gpsLoading ? 0.5 : 1 }}
              >
                <RefreshCw size={16} className={gpsLoading ? 'spin' : ''} />
              </button>
              <button className="close-modal" onClick={closeModal}>
                <X size={18} />
              </button>
            </div>
          </div>

          <div className="modal-body" style={{ padding: 0, height: 'calc(100% - 56px)', overflow: 'hidden' }}>
            <GpsDashboard
              vehicles={gpsVehicles}
              loading={gpsLoading}
              error={gpsError}
              lastUpdated={gpsLastUpdated}
              onRefresh={refreshGps}
              isMobile={isMobile}
            />
          </div>
        </Modal>
      )}

      {/* ---------- MAP MODAL ---------- */}
      {modal === 'map' && (
        <Modal onClose={closeModal} fullscreen>
          <div className="modal-header">
            <h3><Map size={18} /> Live Bus Tracking</h3>
            <button className="close-modal" onClick={closeModal}><X size={18} /></button>
          </div>
          <div className="modal-body map-modal-body">
            <iframe
              src="https://www.openstreetmap.org/export/embed.html?bbox=79.25%2C19.90%2C79.35%2C19.98&amp;layer=mapnik&amp;marker=19.9445%2C79.2880"
              style={{ border: 'none' }}
              title="Live Map"
            ></iframe>
          </div>
          <div className="map-modal-footer">
            <span>Start: <strong>{mapEndpoints.start}</strong></span>
            <span>End: <strong>{mapEndpoints.end}</strong></span>
          </div>
        </Modal>
      )}

      {/* ---------- BOOKING MODAL ---------- */}
      {modal === 'booking' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Armchair} title="Book a Seat" onClose={closeModal} />
          <div className="modal-body">
            <div className="form-group">
              <label>Select Route</label>
              <select>
                <option>Lloyds Colony → Steel Plant Main Gate (07:30 AM)</option>
                <option>Steel Plant Admin Building → Lloyds Colony (12:30 PM)</option>
                <option>Steel Plant Main Gate → Lloyds Colony (06:15 PM)</option>
              </select>
            </div>
            <div className="form-group">
              <label>Select Seat Preference</label>
              <select>
                <option>Window</option>
                <option>Aisle</option>
                <option>Any</option>
              </select>
            </div>
            <button
              className="btn-primary"
              onClick={() => { closeModal(); showToast('Seat Booked Successfully!'); }}
            >
              Confirm Booking
            </button>
          </div>
        </Modal>
      )}

      {/* ---------- MY BOOKINGS MODAL ---------- */}
      {modal === 'myBookings' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Calendar} title="My Bookings" onClose={closeModal} />
          <div className="modal-body">
            <BookingCard tripId="TRIP-1256" route="Lloyds Colony → Steel Plant" date="23 May 2025, 07:30 AM" />
            <BookingCard tripId="TRIP-1257" route="Steel Plant → Lloyds Colony" date="23 May 2025, 06:15 PM" />
          </div>
        </Modal>
      )}

      {/* ---------- SUPPORT MODAL ---------- */}
      {modal === 'support' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Headset} title="Support" onClose={closeModal} />
          <div className="modal-body">
            <div className="notification-item" style={{ borderBottom: 'none', padding: '0 0 15px 0' }}>
              <div className="notif-icon" style={{ background: '#E3F2FD', color: '#1976D2' }}>
                <Phone size={17} />
              </div>
              <div className="notif-content">
                <h4>Call Transport Desk</h4>
                <p>+91 1234512345</p>
              </div>
            </div>
            <div className="notification-item" style={{ borderBottom: 'none', padding: '0 0 15px 0' }}>
              <div className="notif-icon" style={{ background: '#E8F5E9', color: '#2E7D32' }}>
                <Mail size={17} />
              </div>
              <div className="notif-content">
                <h4>Email Support</h4>
                <p>traveldesk@lloyds.in</p>
              </div>
            </div>
            <div className="form-group" style={{ marginTop: 20 }}>
              <label>Describe your issue</label>
              <input type="text" placeholder="Enter issue details..." />
            </div>
            <button
              className="btn-primary"
              onClick={() => { closeModal(); showToast('Support ticket submitted!'); }}
            >
              Submit Ticket
            </button>
          </div>
        </Modal>
      )}

      {/* ---------- QR MODAL ---------- */}
      {modal === 'qr' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={QrCode} title="Scan to Board" onClose={closeModal} />
          <div className="modal-body qr-container">
            <div className="qr-box">
              <img
                src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=LloydsMetalsEmployeeTransport-LM45892"
                alt="QR Code"
              />
            </div>
            <p className="qr-hint">Show this QR code to the driver</p>
            <span className="qr-empid">Employee ID: LM-45892</span>
          </div>
        </Modal>
      )}

      {/* ---------- NOTIFICATIONS MODAL ---------- */}
      {modal === 'notifications' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={Bell} title="Notifications" onClose={closeModal} />
          <div className="modal-body">
            <ul className="notification-list">
              <NotificationItem
                icon={Bus}
                title="Bus Approaching"
                text="Your bus MH 34 AB 1234 is 5 minutes away from Lloyds Colony."
                time="Just now"
              />
              <NotificationItem
                icon={TriangleAlert}
                iconBg="#FFF3E0"
                iconColor="#E65100"
                title="Delay Alert"
                text="Bus MH 34 AB 7890 delayed by 15 mins due to heavy traffic."
                time="10 mins ago"
              />
              <NotificationItem
                icon={CircleCheck}
                iconBg="#E8F5E9"
                iconColor="#2E7D32"
                title="Trip Completed"
                text="You have successfully completed the trip TRIP-1255."
                time="2 hours ago"
              />
            </ul>
          </div>
        </Modal>
      )}

      {/* ---------- PROFILE MODAL ---------- */}
      {modal === 'profile' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={User} title="My Profile" onClose={closeModal} />
          <div className="modal-body">
            <div className="profile-header">
              <div className="profile-avatar"><CircleUser size={36} /></div>
              <h2>Rahul Verma</h2>
              <p>Employee ID: LM-45892</p>
            </div>
            <div className="profile-details">
              <div className="profile-row"><span>Department</span><span>Operations</span></div>
              <div className="profile-row"><span>Shift</span><span>General (9AM - 6PM)</span></div>
              <div className="profile-row"><span>Phone</span><span>+91 98765 43210</span></div>
              <div className="profile-row"><span>Email</span><span>rahul.v@lloyds.in</span></div>
            </div>
          </div>
        </Modal>
      )}

      {/* ---------- FULL SCHEDULE MODAL ---------- */}
      {modal === 'fullSchedule' && (
        <Modal onClose={closeModal}>
          <ModalHeader icon={CalendarDays} title="Full Schedule - Today" onClose={closeModal} />
          <div className="modal-body">
            {filteredSchedule.map((item) => (
              <ScheduleCard
                key={item.id}
                time={item.time}
                route={`${item.fromLocation} → ${item.toLocation}`}
              />
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ============================================
   REUSABLE COMPONENTS
   ============================================ */
const Modal = ({ children, onClose, fullscreen }) => (
  <div
    className="modal-overlay active"
    onClick={(e) => e.target === e.currentTarget && onClose()}
    style={fullscreen ? { padding: 0 } : {}}
  >
    <div className="modal-content" style={fullscreen ? { borderRadius: 0 } : {}}>
      {children}
    </div>
  </div>
);

const ModalHeader = ({ icon: Icon, title, onClose }) => (
  <div className="modal-header">
    <h3><Icon size={18} /> {title}</h3>
    <button className="close-modal" onClick={onClose}><X size={18} /></button>
  </div>
);

const BookingCard = ({ tripId, route, date }) => (
  <div className="card" style={{ boxShadow: 'none', border: '1px solid var(--border-color)', marginBottom: 15 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
      <strong style={{ fontSize: 13 }}>{tripId}</strong>
      <span className="status-badge">Confirmed</span>
    </div>
    <p style={{ fontSize: 12, color: 'var(--text-gray)', marginBottom: 5 }}>{route}</p>
    <p style={{ fontSize: 11, color: 'var(--text-dark)', fontWeight: 500 }}>{date}</p>
  </div>
);

const NotificationItem = ({ icon: Icon, title, text, time, iconBg, iconColor }) => (
  <li className="notification-item">
    <div className="notif-icon" style={{ background: iconBg || '#E3F2FD', color: iconColor || 'var(--blue)' }}>
      <Icon size={17} />
    </div>
    <div className="notif-content">
      <h4>{title}</h4>
      <p>{text}</p>
      <span className="notif-time">{time}</span>
    </div>
  </li>
);

const ScheduleCard = ({ time, route }) => (
  <div className="card" style={{ boxShadow: 'none', border: '1px solid var(--border-color)', marginBottom: 12 }}>
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
      <strong style={{ fontSize: 13 }}>{time}</strong>
      <span className="status-badge">On Time</span>
    </div>
    <p style={{ fontSize: 12, color: 'var(--text-dark)' }}>{route}</p>
  </div>
);

export default App;