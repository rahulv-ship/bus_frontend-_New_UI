import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Modal, { ModalHeader } from './Modal';
import { Map } from 'lucide-react';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const customIcon = (moving) =>
  L.divIcon({
    className: 'custom-leaflet-marker',
    html: `<div class="marker-pin ${moving ? 'moving' : ''}"><i class="fas fa-truck"></i></div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
  });

const GPSTracker = ({ data, onClose }) => {
  const [vehicles, setVehicles] = useState(data || []);
  const [track, setTrack] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(
          'https://api.wheelseye.com/currentLoc?accessToken=98a3355b-4498-48bb-8b70-7b0b04475788'
        );
        const json = await res.json();
        const list = json?.data?.list || [];
        setVehicles(list);
        const moving = list.find((v) => v.speed > 0);
        if (moving) {
          setTrack([
            [19.972, 79.133],
            [19.9705, 79.131],
            [19.969, 79.1295],
            [19.9675, 79.128],
            [19.9662, 79.1265],
            [moving.latitude, moving.longitude],
          ]);
        }
      } catch (e) {
        setVehicles(data || []);
      }
    };
    fetchData();
    const id = setInterval(fetchData, 30000);
    return () => clearInterval(id);
  }, [data]);

  const center =
    vehicles.length > 0
      ? [vehicles[0].latitude, vehicles[0].longitude]
      : [19.9445, 79.288];

  return (
    <Modal onClose={onClose} fullscreen>
      <ModalHeader icon={Map} title="Live GPS Tracking" onClose={onClose} />
      <div className="modal-body" style={{ padding: 0, height: '70vh' }}>
        <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }}>
          <TileLayer
            url="https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}"
            attribution="&copy; Google Maps"
          />
          {track.length > 1 && <Polyline pathOptions={{ color: '#10a56a', dashArray: '6,6' }} positions={track} />}
          {vehicles.map((v) => (
            <Marker key={v.deviceNumber} position={[v.latitude, v.longitude]} icon={customIcon(v.speed > 0)}>
              <Popup>
                <div className="custom-popup">
                  <div className="popup-title">{v.vehicleNumber}</div>
                  <div className="popup-row">
                    <span className="label">Speed</span>
                    <span className="value">{v.speed} km/h</span>
                  </div>
                  <div className="popup-row">
                    <span className="label">Ignition</span>
                    <span className="value">{v.ignition ? 'ON' : 'OFF'}</span>
                  </div>
                  <div className="popup-row">
                    <span className="label">Updated</span>
                    <span className="value">{v.createdDateReadable}</span>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
      <div className="map-modal-footer">
        <span>Total Vehicles: <strong>{vehicles.length}</strong></span>
        <span>Moving: <strong>{vehicles.filter((v) => v.speed > 0).length}</strong></span>
      </div>
    </Modal>
  );
};

export default GPSTracker;