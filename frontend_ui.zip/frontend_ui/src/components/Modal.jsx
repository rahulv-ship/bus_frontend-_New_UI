import React from 'react';
import { useApp } from '../context/AppContext';

const Modal = ({ children, onClose, fullscreen }) => {
  const { closeModal } = useApp();
  return (
    <div
      className={`modal-overlay active`}
      onClick={(e) => e.target === e.currentTarget && (onClose ? onClose() : closeModal())}
      style={fullscreen ? { padding: 0 } : {}}
    >
      <div className="modal-content" style={fullscreen ? { borderRadius: 0 } : {}}>
        {children}
      </div>
    </div>
  );
};

export const ModalHeader = ({ icon: Icon, title, onClose }) => {
  const { closeModal } = useApp();
  return (
    <div className="modal-header">
      <h3>
        {Icon && <Icon size={18} />} {title}
      </h3>
      <button className="close-modal" onClick={onClose || closeModal}>
        <i className="fas fa-times"></i>
      </button>
    </div>
  );
};

export default Modal;