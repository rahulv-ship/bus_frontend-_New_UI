import React from 'react';
import { useApp } from '../context/AppContext';
import { ChevronRight, MapPin } from 'lucide-react';

const TodaysSchedule = ({ scheduleData = [], selectedSchedule, onSelectSchedule }) => {
  const { openMapModal } = useApp();

  return (
    <div className="section" style={{ padding: 0 }}>
      <h2 className="section-title-dark">Today's Schedule</h2>
      <div className="schedule-full-page">
        <div className="schedule-header">
          <h2 className="section-title">Journey Details</h2>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              marginLeft: 'auto',
              justifyContent: 'space-between',
            }}
          >
            <select
              className="schedule-filter"
              onChange={(e) => {
                // handled by parent if needed
              }}
            >
              <option value="all">All</option>
              <option value="pickup">Pickup</option>
              <option value="drop">Drop</option>
              <option value="delayed">Delayed</option>
            </select>
            <div className="view-all">
              View Full <ChevronRight size={12} />
            </div>
          </div>
        </div>
        <div className="schedule-list-scroll">
          {scheduleData.map((item) => (
            <div
              key={item.id}
              className={`schedule-item ${selectedSchedule === item.id ? 'selected' : ''}`}
              onClick={() => onSelectSchedule?.(item.id)}
            >
              <div className="schedule-time">
                {item.time} <span>{item.period}</span>
              </div>
              <div className="schedule-details">
                <div className="schedule-dest-group">
                  <div className="schedule-dest-text">
                    <span className="dest-dot" style={{ background: 'var(--primary-red)' }} />
                    <div>
                      {item.fromLocation} <span>{item.fromSub}</span>
                    </div>
                  </div>
                  <button
                    className="schedule-gps-btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      openMapModal(item.fromLocation, item.toLocation);
                    }}
                    title="View on Map"
                  >
                    <MapPin size={12} />
                  </button>
                </div>
                <div className="schedule-dest-group">
                  <div className="schedule-dest-text">
                    <span className="dest-dot" style={{ background: 'var(--dark-bg)' }} />
                    <div>
                      {item.toLocation} <span>{item.toSub}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="status-badge"
                style={
                  item.status === 'Delayed'
                    ? { background: '#FFF3E0', color: '#E65100' }
                    : {}
                }
              >
                {item.status}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TodaysSchedule;