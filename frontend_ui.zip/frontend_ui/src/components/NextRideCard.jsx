import React from 'react';
import { useApp } from '../context/AppContext';
import { Bus, MapPin, Flag, Clock } from 'lucide-react';

const NextRideCard = () => {
  const { openMapModal } = useApp();

  return (
    <div className="section" style={{ padding: 0 }}>
      <h2 className="section-title-dark">My Next Ride</h2>
      <div className="card next-ride-card">
        <div className="ride-header">
          <div className="bus-info">
            <div className="bus-icon-box">
              <Bus size={16} />
            </div>
            <div>
              <h3>Tata Marco Polo Bus</h3>
              <p>52 Seater</p>
            </div>
          </div>
          <div className="ride-header-right">
            <div className="badge-confirmed">Confirmed</div>
            <button
              className="gps-icon-btn"
              onClick={() => openMapModal('Lloyds Colony', 'Steel Plant Main Gate')}
              title="View on Map"
            >
              <MapPin size={13} />
              <span>GPS</span>
            </button>
          </div>
        </div>

        <div className="ride-route">
          <div className="route-line">
            <div className="dot"></div>
            <div className="dash"></div>
            <div className="dot" style={{ background: 'var(--dark-bg)' }}></div>
          </div>
          <div className="route-text">
            <div className="destination-group">
              <p>
                Lloyds Colony <span>Start Point</span>
              </p>
            </div>
            <div className="destination-group">
              <p>
                Steel Plant Main Gate <span>End Destination</span>
              </p>
            </div>
          </div>
        </div>

        <div className="ride-footer">
          <div className="time-box">
            <Clock size={14} />
            <div>
              <p>07:30 AM</p>
              <p>Pickup Time</p>
            </div>
          </div>
          <div className="time-box">
            <Flag size={14} />
            <div>
              <p>07:50 AM</p>
              <p>Drop Time</p>
            </div>
          </div>
        </div>

        <div className="bus-details-section">
          <img src="/Bus_view.png" alt="Bus Details" className="details-image" />
          <div className="details-footer">
            <div className="detail-item">
              <Bus size={13} />
              <div>
                <div>52 Seater</div>
                <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Tata Marco Polo</div>
              </div>
            </div>
            <div className="detail-item">
              <Flag size={13} />
              <div>
                <div>MH 34 AB 1234</div>
                <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Registration No.</div>
              </div>
            </div>
            <div className="detail-item">
              <MapPin size={13} />
              <div>
                <div>Rahul Verma</div>
                <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Driver</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NextRideCard;