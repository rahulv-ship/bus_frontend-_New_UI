import React from 'react';
import { busDetails } from '../data/mockData';

const BusDetailsCard = () => (
  <div className="card">
    <img src="Bus_view.png" alt="Bus Details" className="details-image" />
    <div className="details-footer">
      <div className="detail-item">
        <i className="fas fa-user-friends"></i>
        <div>
          <div>{busDetails.capacity}</div>
          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>{busDetails.model}</div>
        </div>
      </div>
      <div className="detail-item">
        <i className="fas fa-id-card"></i>
        <div>
          <div>{busDetails.registration}</div>
          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Registration No.</div>
        </div>
      </div>
      <div className="detail-item">
        <i className="fas fa-user-circle"></i>
        <div>
          <div>{busDetails.driver}</div>
          <div style={{ fontWeight: 400, color: 'var(--text-gray)' }}>Driver</div>
        </div>
      </div>
    </div>
  </div>
);

export default BusDetailsCard;