import React from 'react';
import {
  Home,
  Armchair,
  Calendar,
  MapPin,
  Headset,
  QrCode,
  Bell,
  User,
  LogOut,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

const Header = ({ activeTab, onTabChange }) => {
  const { openModal } = useApp();

  return (
    <div className="top-bar">
      <div className="top-bar-left">
        <div className="logo-image">
          <img src="/Logo.png" alt="Lloyds Metals Logo" />
        </div>
      </div>
      <div className="top-bar-right">
        <div className="top-nav-tabs">
          <div
            className={`top-nav-item ${activeTab === 'My Pass' ? 'active' : ''}`}
            onClick={() => onTabChange?.('My Pass')}
          >
            <QrCode size={16} />
            <span>My Pass</span>
          </div>
        </div>
        <div className="notification-icon" onClick={() => openModal('notifications')}>
          <Bell size={20} />
        </div>
        <div className="profile-avatar-btn" onClick={() => openModal('profile')}>
          RV
        </div>
      </div>
    </div>
  );
};

export default Header;