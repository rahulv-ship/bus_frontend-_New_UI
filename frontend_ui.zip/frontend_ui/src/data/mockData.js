export const nextRide = {
  busName: 'Tata Marco Polo Bus',
  busType: '52 Seater',
  status: 'Confirmed',
  startPoint: 'Lloyds Colony',
  startLabel: 'Start Point',
  endPoint: 'Steel Plant Main Gate',
  endLabel: 'End Destination',
  pickupTime: '07:30 AM',
  dropTime: '07:50 AM',
};

export const busDetails = {
  capacity: '52 Seater',
  model: 'Tata Marco Polo',
  registration: 'MH 34 AB 1234',
  driver: 'Rahul Verma',
};

export const schedules = [
  {
    id: 1,
    time: '07:30 AM',
    period: 'Pickup',
    from: 'Lloyds Colony',
    fromSub: 'Near Main Gate',
    to: 'Steel Plant Main Gate',
    toSub: 'End Destination',
    status: 'On Time',
  },
  {
    id: 2,
    time: '12:30 PM',
    period: 'Pickup',
    from: 'Steel Plant',
    fromSub: 'Admin Building',
    to: 'Lloyds Colony',
    toSub: 'End Destination',
    status: 'On Time',
  },
  {
    id: 3,
    time: '06:15 PM',
    period: 'Pickup',
    from: 'Steel Plant',
    fromSub: 'Main Gate',
    to: 'Lloyds Colony',
    toSub: 'End Destination',
    status: 'On Time',
  },
];

export const bookings = [
  {
    id: 'TRIP-1256',
    route: 'Lloyds Colony → Steel Plant',
    date: '23 May 2025, 07:30 AM',
    status: 'Confirmed',
  },
  {
    id: 'TRIP-1257',
    route: 'Steel Plant → Lloyds Colony',
    date: '23 May 2025, 06:15 PM',
    status: 'Confirmed',
  },
];

export const notifications = [
  {
    id: 1,
    icon: 'fa-bus',
    title: 'Bus Approaching',
    message: 'Your bus MH 34 AB 1234 is 5 minutes away from Lloyds Colony.',
    time: 'Just now',
    color: null,
  },
  {
    id: 2,
    icon: 'fa-exclamation-triangle',
    title: 'Delay Alert',
    message: 'Bus MH 34 AB 7890 delayed by 15 mins due to heavy traffic.',
    time: '10 mins ago',
    color: { bg: '#FFF3E0', color: '#E65100' },
  },
  {
    id: 3,
    icon: 'fa-check-circle',
    title: 'Trip Completed',
    message: 'You have successfully completed the trip TRIP-1255.',
    time: '2 hours ago',
    color: { bg: '#E8F5E9', color: '#2E7D32' },
  },
];

export const profile = {
  name: 'Rahul Verma',
  employeeId: 'LM-45892',
  department: 'Operations',
  shift: 'General (9AM - 6PM)',
  phone: '+91 98765 43210',
  email: 'rahul.v@lloyds.in',
};