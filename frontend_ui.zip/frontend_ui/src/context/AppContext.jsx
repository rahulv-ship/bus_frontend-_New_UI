import React, { createContext, useContext, useState, useCallback } from 'react';

const AppContext = createContext();

export const useApp = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
  const [activeModal, setActiveModal] = useState(null);
  const [mapData, setMapData] = useState({ start: '', end: '' });
  const [toast, setToast] = useState({ show: false, message: '' });
  const [activeTab, setActiveTab] = useState('Home');

  const showToast = useCallback((message) => {
    setToast({ show: true, message });
    setTimeout(() => setToast({ show: false, message: '' }), 2500);
  }, []);

  const openModal = useCallback((id) => setActiveModal(id), []);
  const closeModal = useCallback(() => setActiveModal(null), []);

  const openMapModal = useCallback((start, end) => {
    setMapData({ start, end });
    setActiveModal('map');
  }, []);

  const value = {
    activeModal,
    openModal,
    closeModal,
    mapData,
    openMapModal,
    toast,
    showToast,
    activeTab,
    setActiveTab,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};